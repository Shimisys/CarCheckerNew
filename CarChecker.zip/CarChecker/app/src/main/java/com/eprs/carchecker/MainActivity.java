package com.eprs.carchecker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;

import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private ArrayList<String> categoryList = new ArrayList<String>();
    private ArrayList<String> tagDetailsArr = new ArrayList<String>();
    private ArrayList<String> carNumber1 = new ArrayList<String>();
    private List<CarTag> list = new ArrayList<CarTag>();
    private ArrayList<String> carNumber, tagIsseuData, tagType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setPointer();
    }

    private void setPointer() {

        List<String[]> list = new ArrayList<String[]>();

        String next[] = {"|"};
        try {
            InputStreamReader csvStreamReader = new InputStreamReader(
                    MainActivity.this.getAssets().open(
                            "foo.csv"));

            CSVReader reader = new CSVReader(csvStreamReader);
            for (;;) {
                next = reader.readNext();
                if (next != null) {
                    list.add(next);
                } else {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            categoryList.add(list.get(i)[0]);
        }
        Log.e(TAG, "setPointer: " + categoryList + list);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getApplicationContext(), android.R.layout.simple_spinner_item,
                categoryList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        getCsvArr();
    }

    private void getCsvArr() {
        for (int i = 0; i<10; i++){
            Log.e(TAG, "getCsvArr:ca " + categoryList );
            String[] a = categoryList.get(i).split("\\|");
            Log.e(TAG, "shimon: " + a[i]);

//            CarTag carTag = new CarTag(a[i], a[i], a[i]);
//            list.add(carTag);
//
//            Log.e(TAG, "shimon: " + list.get(i).getCarNumber());
//            tagDetailsArr.add(Arrays.toString(categoryList.get(i).split("\\|",-1)));
//            Log.e(TAG, "getCsvArr:tag " + tagDetailsArr.get(i));
//            String [] record = tagDetailsArr.get(i).split(",");
//            Log.e(TAG, "getCsvArr: " + record.toString() );
        }
    }



}
